# Edu-Mail-Generator
Generate Free Edu Mail(s) within minutes

## ***Requirements***

- Python `3.7 or >`
- Python `pip`

## ***Installation***

	  python3 setup.py
It will download all required packages and webdrivers automatically based on your browsers versions (You need not to install them seprately)

## ***Usage***

	  python3 bot.py
Follow the instructions to get started with generating your own edu mail

## ***Features***

- One click install/setup.
- No programming knowledge needed (other then python3 with pip installed).
- Setup will install all webdrivers needed automatically based on your browsers.
- Many more features.

## ***Why should you use it ?***

- It saves the time by doing the work for you (It usually takes 10 to 15 minutes to fill a form manually)
- No limit on creating edu mails. You can create as much as you need (preferred to use in limits)
- Many benefits of having an edu mail like `Spotify 50% off` `Apple music 50% off` `Discount on Adobe CC` `Free amazon prime` and many more
